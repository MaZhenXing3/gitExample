#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <vector>

using namespace std;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(string assetDir)
		: GameWorld(assetDir)
	{
        m_tunnelman = nullptr;
        actors.clear();
        
	}

	virtual int init()
	{
		return GWSTATUS_CONTINUE_GAME;
	}

	virtual int move()
	{
		// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
		// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
		decLives();
		return GWSTATUS_PLAYER_DIED;
	}

	virtual void cleanUp()
	{
	}
    
    virtual ~StudentWorld(){
        cleanUp();
    }
    
    bool isValidPos(int x, int y){
        if (x < 0 || x > VIEW_WIDTH - SPRITE_WIDTH + 1){
            return false;
        }
        else if (y < 0 || y > VIEW_HEIGHT - SPRITE_HEIGHT + 1){
            return false;
        }
        else{
            return true;
        }
    }

private:
    TunnelMan *m_tunnelman;
    std::vector<Actor*> actors;
};

#endif // STUDENTWORLD_H_

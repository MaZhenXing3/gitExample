#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor : public GraphObject
{
public:
    // the base class for all of the objects in this project
    Actor(StudentWorld *world, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0):
    GraphObject(imageID, startX, startY, dir, size, depth), m_world(world) {
        setVisible(true);
    }
    StudentWorld*  getWorld(){ return m_world; }
    virtual void doSomething() = 0;
    
private:
    StudentWorld * m_world;
};
// base class of tunnelman and protesters 
class LivingActor : public Actor
{
public:
    LivingActor(StudentWorld *world, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0):
    Actor(world, imageID, startX, startY, dir, size, depth), alive(true){}
    virtual void die(){ alive = false; return;}
    bool isalive() {return alive;}
    virtual void walkto(int x, int y);
    
private:
    bool alive;
};

class TunnelMan : public LivingActor
{
public:
    TunnelMan(StudentWorld *world, int hits = 10, int waters = 5, int sonars = 1, int nuggets = 0):
    LivingActor(world, TID_PLAYER, 30, 60), m_hit(hits), m_water(waters), m_sonar(sonars), m_nugget(nuggets){}
    virtual void getAnnoyed();
    virtual void doSomething();
    
private:
    // can squirt
    // can move
    // can get annoyed
    int m_hit;
    int m_water;
    int m_sonar;
    int m_nugget;
    
};

class Earth : public Actor
{
    
public:
    Earth(StudentWorld *world, int startX, int startY, Direction dir = right, int size = 0.25, int depth = 3):Actor(world, TID_EARTH, startX, startY, dir, size, depth){
        setVisible(true);
    }
    
private:
    
};

#endif // ACTOR_H_

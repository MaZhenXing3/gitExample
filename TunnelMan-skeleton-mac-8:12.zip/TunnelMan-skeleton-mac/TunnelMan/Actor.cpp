#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
void LivingActor::walkto(int x,int y){
    if (getWorld()->isValidPos(x, y)){
        moveTo(x,y);
    }
}

void TunnelMan::getAnnoyed(){
    m_hit--;
    if (m_hit == 0){
        die();
    }
    return;
}

void TunnelMan::doSomething(){
    int ch;
    if (getWorld()->getKey(ch)){
        switch (ch) {
            case KEY_PRESS_UP:
                walkto(getX(),getY() + 1);
                break;
            case KEY_PRESS_DOWN:
                walkto(getX(),getY() - 1);
                break;
                
            case KEY_PRESS_LEFT:
                walkto(getX() - 1,getY());
                break;
                
            case KEY_PRESS_RIGHT:
                walkto(getX() + 1,getY());
                break;
            // add press_tab, press_z,press_space, press_esc;
                
                
            default:
                break;
        }
    }
    
}
